package basics;

public class oop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name = "Steve";
		String email = "pen51767@outlook.com";
		String phone = "7812965388";
		
		// Action, activity, behavior		
		walking(name);
		System.out.println(name + " is walking");
		System.out.println(name + " is eating");

		//
	}
	static void walking(String name)	{
		System.out.println(name + " is walking");
	}
}
