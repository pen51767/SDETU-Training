package labs;

public interface IInterest {
	public double rate = 4.5;
	
	public void accrue();
}
