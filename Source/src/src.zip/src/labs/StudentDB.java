package labs;

public class StudentDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentData student1 = new StudentData("987654321");
		
		student1.setfirstName("Steven");
		student1.setlastName("Pensyl");
		System.out.println(student1.getfirstName() + " " + student1.getlastName());
	}

}

class StudentData	{
	private String id = "1000";
	private String firstName;
	private String lastName;
	private String email;	// email based on 1st Letter of FirstName and entire LastName
	private String SSN;
	
	public StudentData(String SSN) {
		//setEmail();
		setstudentID();
		setEmail();
		this.SSN = SSN;
		
	}	 
	
	private void setstudentID()	{
		int random = (int) (Math.random() * 10000);
		id = id + "" + random + (SSN.length() - 4);
		System.out.println("YOUR STUDENT ID IS: " + id);
		}

	
	private void setEmail()	{
		email = firstName.substring(0, 1) + lastName + "@school.com";
		}
		
	
	public void setfirstName(String firstName)	{
		this.firstName = firstName;
	}
	
	public String getfirstName()	{
		return firstName;
	}
	
	public void setlastName(String lastName)	{
		this.lastName = lastName;
	}
	
	public String getlastName()	{
		return lastName;
	}
	
	public void setstudentID(String id)	{
		this.id = id;
	}
	
	public String getstudentID()	{
		return id;
	}
	
	public void setEmail(String email)	{
		this.email = email;
	}
	
	public String getEmail()	{
		return email;
	}
}