package oop;

public interface IRate {
	
	public void setRate();
	public void increaseRate();

}
