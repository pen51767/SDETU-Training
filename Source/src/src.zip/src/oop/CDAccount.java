package oop;

public class CDAccount extends BankAccount {
	
	String interestRate;
	
	void compound()	{
		System.out.println("Compunding Interest");
	}

}